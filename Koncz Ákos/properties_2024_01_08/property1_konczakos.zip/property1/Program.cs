﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace property1
{
    class Program
    {
        class Ember
        {
            public Ember(string n, int é, int isz)
            {
                Név = n; Életkor = é; Irányítószám = isz;
            }

            private string nev;
            private string Név
            {
                get { return nev; }
                set
                {
                    if (value.Length != 0) nev = value;
                    else Exception("A név mező nem lehet üres!");
                }
            }
            private int eletkor;
            public int Életkor
            {
                get { return eletkor; }
                set
                {
                    if (value >= 0) Életkor = value;
                    else Exception("Az életkor mező nem lehet negatív");
                }
            }
            private int iranyitoszam;
            public int Irányítószám
            {
                get { return iranyitoszam; }
                set
                {
                    if (value.ToString().Length == 4) iranyitoszam = value;
                    else Exception("Az irányítószám mező helytelen");
                }
            }
            private void Exception(string s)
            {
                throw new FormatException(s);
            }
        }
        static void Main(string[] args)
        {
            Ember e = new Ember("Jani", 10, 1101);

            Console.WriteLine(e.Név);
            Console.WriteLine(e.Életkor);
            Console.WriteLine(e.Irányítószám);
        }
    }
}
