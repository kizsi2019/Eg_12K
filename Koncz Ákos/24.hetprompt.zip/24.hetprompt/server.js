const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const app = express();
const port = 3000;

// Specify the path to the database file within the 'database' folder
const dbPath = 'database/felhasznalok.db';

// Connect to SQLite database
const db = new sqlite3.Database(dbPath, (err) => {
 if (err) {
    return console.error(err.message);
 }
 console.log(`Connected to the SQLite database at ${dbPath}`);
});

// Create table for users if it doesn't exist
db.run('CREATE TABLE IF NOT EXISTS users (username text, password text)', (err) => {
 if (err) {
    return console.error(err.message);
 }
});

// Use built-in middleware to parse JSON and URL-encoded bodies
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Handle login requests
app.post('/login', (req, res) => {
 const { username, password } = req.body;
 // Here you would typically check the database for the user's credentials
 // For simplicity, we'll just echo back the credentials
 res.send(`Username: ${username}, Password: ${password}`);
});

// Start the server
app.listen(port, () => {
 console.log(`Server running at http://localhost:${port}`);
});