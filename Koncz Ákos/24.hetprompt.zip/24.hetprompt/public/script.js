const request = new XMLHttpRequest()
request.onreadystatechange = function(){
    if(this.status == 200){
        
    }
}